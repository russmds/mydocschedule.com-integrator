<?php
/**
Copyright 2011-2012 Nick Korbel

This file is part of phpScheduleIt.

phpScheduleIt is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

phpScheduleIt is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with phpScheduleIt.  If not, see <http://www.gnu.org/licenses/>.
*/

require_once(ROOT_DIR . 'lib/external/pear/Config.php');

interface IConfiguration extends IConfigurationFile
{
	public function Register($configFile, $configId);
	public function File($configId);
}

interface IConfigurationFile
{
	/**
	 * @abstract
	 * @param string $section
	 * @param string $name
	 * @param null|IConvert $converter
	 * @return mixed|string
	 */
	public function GetSectionKey($section, $name, $converter = null);

	/**
	 * @abstract
	 * @param string $name
	 * @param null|IConvert $converter
	 * @return mixed|string
	 */
	public function GetKey($name, $converter = null);

    /**
     * @abstract
     * @return string the full url to the root of this phpScheduleIt instance WITHOUT the trailing /
     */
	public function GetScriptUrl();		
}

class Configuration implements IConfiguration
{
    /**
     * @var array|Configuration[]
     */
	protected $_configs = array();

    /**
     * @var Configuration
     */
	private static $_instance = null;

	const SETTINGS = 'settings';
	const DEFAULT_CONFIG_ID = 'integration';
	const DEFAULT_CONFIG_FILE_PATH = 'config/config.php';

    const VERSION = '1.0';

	protected function __construct()
	{
	}

	/**
	 * @return IConfigurationFile
	 */
	public static function Instance()
	{
		if (self::$_instance == null)
		{
			self::$_instance = new Configuration();
			self::$_instance->Register(dirname(__FILE__) . '/../../' . self::DEFAULT_CONFIG_FILE_PATH,
									   self::DEFAULT_CONFIG_ID);
		}

		return self::$_instance;
	}

	public static function SetInstance($value)
	{
		self::$_instance = $value;
	}

	public function Register($configFile, $configId, $overwrite = false)
	{
		if (!file_exists($configFile))
        {
			echo "Missing config file: $configFile. If there is a .dist config file in this location, please copy it as $configFile";
            throw new Exception("Missing config file: $configFile");
        }

		$config = new Config();
		
		$container = $config->parseConfig($configFile, 'PHPArray');

		if (is_a($container, 'PEAR_Error'))
		{
			throw new Exception($container->getMessage());
		}

		$this->AddConfig($configId, $container, $overwrite);
	}

    /**
     * @param $configId
     * @return Configuration
     */
	public function File($configId)
	{
		return $this->_configs[$configId];
	}

	public function GetSectionKey($section, $keyName, $converter = null)
	{
		return $this->File(self::DEFAULT_CONFIG_ID)->GetSectionKey($section, $keyName, $converter);
	}

	public function GetKey($keyName, $converter = null)
	{
		return $this->File(self::DEFAULT_CONFIG_ID)->GetKey($keyName, $converter);
	}

	public function GetScriptUrl()
	{
		return $this->File(self::DEFAULT_CONFIG_ID)->GetScriptUrl();
	}

	protected function AddConfig($configId, $container, $overwrite)
	{
		if (!$overwrite)
		{
			if (array_key_exists($configId, $this->_configs))
			{
				throw new Exception('Configuration already exists');
			}
		}

		$this->_configs[$configId] = new ConfigurationFile($container->getItem("section", self::SETTINGS)->toArray());
	}
	
	public function SetKeyValue($section = null, $keyName, $value)
	{
		$this->File(self::DEFAULT_CONFIG_ID)->SetKeyValue($section, $keyName, $value);
	}
	
	public function SaveSectionKey($section = null, $key = null)
	{
		if (is_null($section) && is_null($key))
			return;
		
		$path = dirname(__FILE__) . '/../../' . self::DEFAULT_CONFIG_FILE_PATH;
		
		$content = file($path);
		
		$newContent = array();
		
		$pattern1 = '/' . ((!is_null($section)) ? $section : '.*') .'/';
		
		$pattern2 = '/' . ((!is_null($key)) ? $key : '.*') . '/';

		foreach ($content as $line)
		{						
			if (preg_match($pattern1, $line) && preg_match($pattern2, $line))
			{
				list($lineKey, $lineValue) = explode('=', $line);
				
				if (!is_null($section))
				{
					if (!is_null($key))
					{
						$value = $this->File(self::DEFAULT_CONFIG_ID)->GetSectionKey($section, $key, null);
					}else
					{
						//not supported for now
						//$value = $this->File(self::DEFAULT_CONFIG_ID)->GetSection($section);
					}
				}else
				{
					$value = $this->File(self::DEFAULT_CONFIG_ID)->GetKey($key, $converter);
				}				
				$line = $lineKey . "= '" . $value . "';\n";
			}
			$newContent[] = $line;
		}
		copy($path, $path . '.orig');
		
		file_put_contents($path, implode('', $newContent));
	}
}

class ConfigurationFile implements IConfigurationFile
{
	private $_values = array();

	public function __construct($values)
	{
		$this->_values = $values[Configuration::SETTINGS];
	}

	public function GetKey($keyName, $converter = null)
	{
		if (array_key_exists($keyName, $this->_values))
		{
			return $this->Convert($this->_values[$keyName], $converter);
		}
		return null;
	}

	public function GetSectionKey($section, $keyName, $converter = null)
	{
		if (array_key_exists($section, $this->_values) && array_key_exists($keyName, $this->_values[$section]))
		{
			return $this->Convert($this->_values[$section][$keyName], $converter);
		}
		return null;
	}

	public function GetSection($section)
	{
		if (array_key_exists($section, $this->_values))
		{
			return $this->_values[$section];
		}
		return null;
	}
	
	public function GetScriptUrl()
	{
		$url = $this->GetKey(ConfigKeys::SCRIPT_URL);

		return rtrim($url, '/');
	}

	protected function Convert($value, $converter)
	{
		if (!is_null($converter))
		{
			return $converter->Convert($value);
		}

		return $value;
	}
	
	public function SetKeyValue($section, $keyName, $value)
	{
		if (is_null($section))
		{
			if (array_key_exists($keyName, $this->_values))
			{
				$this->_values[$keyName] = $value;
				
				return true;
			}
			return false;
		}else
		{
			if (array_key_exists($section, $this->_values) && array_key_exists($keyName, $this->_values[$section]))
			{
				$this->_values[$section][$keyName] = $value;
				
				return true;
			}
			return false;
		}
	}	
}