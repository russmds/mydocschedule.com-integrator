<?php
/**
Copyright 2011-2016 Russ Profant

This file is part of MyDocSchedule.com Integration package.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
*/

require_once('BaseIntegrator.php');
require_once('Oscar/OscarIntegrator.php');
